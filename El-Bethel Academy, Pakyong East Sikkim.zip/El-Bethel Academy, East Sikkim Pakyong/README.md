# school-collage-management-system-v1.1
Design by w3layouts and developed by Ravi Khadka ---Fully 100% Dynamic with core PHP --- ----School/college Management system------ Upgraded to fully compatible PHP 7.x Added Guardian Email in Student Profile -----Features Enhancement------ Added SMS / Email notifications for Student Admission, Fees Submission, Exam Results, Absent Student, User
